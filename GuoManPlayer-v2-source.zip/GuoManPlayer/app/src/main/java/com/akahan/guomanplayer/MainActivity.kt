package com.akahan.guomanplayer

import android.os.Bundle
import android.content.Context
import android.view.ViewGroup
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URL

private val Ink = Color(0xFF130D12)
private val Panel = Color(0xFF241720)
private val Accent = Color(0xFFE84A64)
private val Muted = Color(0xFFB9AAB2)

data class Episode(val title: String, val url: String)
data class Drama(val id: String, val title: String, val category: String, val description: String, val cover: String, val episodes: List<Episode>)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GuoManApp() }
    }
}

@Composable
fun GuoManApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var feedUrl by remember { mutableStateOf(context.getSharedPreferences("gm", Context.MODE_PRIVATE).getString("feed", "") ?: "") }
    var dramas by remember { mutableStateOf<List<Drama>>(emptyList()) }
    var selected by remember { mutableStateOf<Drama?>(null) }
    var query by remember { mutableStateOf("") }
    var showSource by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("添加一个你有权使用的漫剧目录 JSON 地址，即可同步内容。") }
    var tab by remember { mutableStateOf("推荐") }

    MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Ink, surface = Panel)) {
        Surface(Modifier.fillMaxSize(), color = Ink) {
            Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
                Spacer(Modifier.height(20.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("GUOMAN", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                        Text("漫剧放映厅", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
                    }
                    Text("＋ 内容源", color = Color.White, modifier = Modifier.background(Panel, RoundedCornerShape(20.dp)).clickable { showSource = true }.padding(horizontal = 14.dp, vertical = 10.dp))
                }
                Spacer(Modifier.height(16.dp))
                Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("⌕", color = Muted, fontSize = 22.sp)
                    Spacer(Modifier.width(8.dp))
                    Box(Modifier.weight(1f)) {
                        if (query.isEmpty()) Text("搜索漫剧名称、题材", color = Muted)
                        BasicTextField(query, { query = it }, singleLine = true, textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 15.sp))
                    }
                    Text("搜索", color = Accent, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    listOf("推荐", "热血", "恋爱", "悬疑", "奇幻").forEach { label ->
                        Text(label, color = if (tab == label) Color.White else Muted, modifier = Modifier.background(if (tab == label) Accent else Panel, RoundedCornerShape(18.dp)).clickable { tab = label }.padding(horizontal = 14.dp, vertical = 8.dp), fontSize = 13.sp)
                    }
                }
                Spacer(Modifier.height(14.dp))
                if (selected != null) {
                    DramaDetail(selected!!, onBack = { selected = null })
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("为你发现", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Text(if (loading) "同步中…" else "刷新", color = Accent, modifier = Modifier.clickable {
                            if (feedUrl.isNotBlank()) scope.launch {
                                loading = true
                                try { dramas = loadFeed(feedUrl); error = "已同步 ${dramas.size} 部漫剧" }
                                catch (e: Exception) { error = "同步失败：${e.message ?: "请检查目录地址"}" }
                                loading = false
                            } else showSource = true
                        }.padding(8.dp))
                    }
                    Text(error, color = Muted, fontSize = 12.sp)
                    Spacer(Modifier.height(8.dp))
                    val filtered = dramas.filter { (it.title + it.category).contains(query, true) && (tab == "推荐" || it.category.contains(tab)) }
                    if (filtered.isEmpty()) {
                        Column(Modifier.fillMaxWidth().weight(1f), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                            Text("✦", color = Accent, fontSize = 42.sp)
                            Text("你的下一部漫剧，在这里发现", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(8.dp))
                            Text("接入授权内容目录后，封面、简介和剧集会自动同步。", color = Muted, fontSize = 13.sp)
                            Spacer(Modifier.height(16.dp))
                            Button(onClick = { showSource = true }, colors = ButtonDefaults.buttonColors(containerColor = Accent)) { Text("添加内容源") }
                        }
                    } else {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.weight(1f)) {
                            items(filtered) { drama ->
                                Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).clickable { selected = drama }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Box(Modifier.size(74.dp, 96.dp).background(Color(0xFF563044), RoundedCornerShape(9.dp)), contentAlignment = Alignment.Center) { Text("漫剧", color = Color.White, fontWeight = FontWeight.Bold) }
                                    Spacer(Modifier.width(13.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(drama.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                        Text("${drama.category} · ${drama.episodes.size} 集", color = Accent, fontSize = 12.sp)
                                        Spacer(Modifier.height(5.dp))
                                        Text(drama.description, color = Muted, fontSize = 12.sp, maxLines = 2)
                                    }
                                }
                            }
                        }
                    }
                }
                Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), horizontalArrangement = Arrangement.SpaceAround) {
                    listOf("首页", "分类", "收藏", "我的").forEach { Text(it, color = if (it == "首页") Accent else Muted, fontSize = 13.sp) }
                }
            }
        }
    }
    if (showSource) {
        AlertDialog(onDismissRequest = { showSource = false }, containerColor = Panel, title = { Text("添加漫剧内容源", color = Color.White) },
            text = { Column {
                Text("填入你有权使用的 JSON 目录 HTTPS 地址。平台需要提供开放接口或授权 API。", color = Muted, fontSize = 13.sp)
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(value = feedUrl, onValueChange = { feedUrl = it }, label = { Text("内容目录 URL") }, singleLine = true)
            } },
            confirmButton = { TextButton(onClick = {
                context.getSharedPreferences("gm", Context.MODE_PRIVATE).edit().putString("feed", feedUrl).apply()
                showSource = false
                if (feedUrl.isNotBlank()) scope.launch {
                    loading = true
                    try { dramas = loadFeed(feedUrl); error = "已同步 ${dramas.size} 部漫剧" }
                    catch (e: Exception) { error = "同步失败：${e.message ?: "请检查接口"}" }
                    loading = false
                }
            }) { Text("保存并同步", color = Accent) } },
            dismissButton = { TextButton(onClick = { showSource = false }) { Text("取消", color = Muted) } })
    }
}

@Composable
fun DramaDetail(drama: Drama, onBack: () -> Unit) {
    var current by remember { mutableStateOf<Episode?>(null) }
    val context = LocalContext.current
    val player = remember { ExoPlayer.Builder(context).build() }
    DisposableEffect(Unit) { onDispose { player.release() } }
    Column(Modifier.fillMaxSize()) {
        Text("‹ 返回", color = Accent, modifier = Modifier.clickable { onBack() }.padding(vertical = 8.dp))
        Text(drama.title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text(drama.description, color = Muted, fontSize = 13.sp)
        if (current != null) {
            AndroidView(factory = { ctx -> PlayerView(ctx).apply { this.player = player; layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 220) } },
                modifier = Modifier.fillMaxWidth().height(220.dp))
            Text("正在播放：${current!!.title}", color = Color.White, modifier = Modifier.padding(vertical = 8.dp))
        } else Text("选择剧集开始播放", color = Muted, modifier = Modifier.padding(vertical = 12.dp))
        Text("选集", color = Color.White, fontWeight = FontWeight.Bold)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(drama.episodes) { episode ->
                Text(episode.title, color = Color.White, modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(10.dp)).clickable {
                    current = episode
                    player.setMediaItem(MediaItem.fromUri(episode.url)); player.prepare(); player.play()
                }.padding(14.dp))
            }
        }
    }
}

private suspend fun loadFeed(address: String): List<Drama> = withContext(Dispatchers.IO) {
    require(address.startsWith("https://")) { "仅支持 HTTPS 内容目录" }
    val text = URL(address).openConnection().apply { connectTimeout = 10000; readTimeout = 15000 }.getInputStream().bufferedReader().use { it.readText() }
    val root = JSONObject(text)
    val array = root.getJSONArray("dramas")
    (0 until array.length()).map { i ->
        val d = array.getJSONObject(i)
        val eps = d.optJSONArray("episodes")
        val episodes = if (eps == null) emptyList() else (0 until eps.length()).map { j ->
            val e = eps.getJSONObject(j); Episode(e.optString("title", "第${j + 1}集"), e.getString("url"))
        }
        Drama(d.optString("id", i.toString()), d.getString("title"), d.optString("category", "其他"), d.optString("description", ""), d.optString("cover", ""), episodes)
    }
}
