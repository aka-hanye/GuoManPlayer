# GuoManPlayer 2.0

Android app shell for a lawful multi-source manhua/short-animation catalog.

## Build
Run `gradle assembleDebug` from this directory with Android SDK 35 and JDK 17.

## Content feed
Add an HTTPS JSON catalog URL in the app. Expected shape:

```json
{
  "dramas": [
    {
      "id": "demo-001",
      "title": "Example title",
      "category": "奇幻",
      "description": "Synopsis",
      "cover": "https://example.com/cover.jpg",
      "episodes": [
        { "title": "第1集", "url": "https://cdn.example.com/episode1.m3u8" }
      ]
    }
  ]
}
```

Only use feeds and stream URLs that you own or are authorized to distribute. Media3 supports common progressive media and HLS; DRM playback requires the provider's authorized license configuration. No third-party platform scraping, login bypass, or DRM circumvention is included.
