# GuoManPlayer（果漫播放器）

一个面向 Android 的轻量漫剧播放器项目，采用简洁清爽风格。当前首版实现：

- 首页快捷入口
- 本地视频选择与 Media3 播放
- 首页、漫剧播放、收藏、历史四个主导航
- 为红果官方应用跳转预留入口（尚未接入，避免错误猜测第三方包名或链接）
- GitHub Actions 云端构建 APK

## 构建

需要 JDK 17、Android SDK 35、Gradle 8.9：

```bash
gradle assembleDebug
```

APK 输出：`app/build/outputs/apk/debug/app-debug.apk`

也可以把本项目上传到 GitHub 的 `main` 分支，Actions 会自动构建并上传 APK artifact。

## 当前版本边界

这是可继续开发的首版工程，不是已经验证通过的最终 APK。收藏/历史持久化、在线 AI 漫剧目录、红果官方应用跳转、网络视频播放和 UI 细节仍需后续实现与真机测试。不要把本项目误认为红果官方客户端。
