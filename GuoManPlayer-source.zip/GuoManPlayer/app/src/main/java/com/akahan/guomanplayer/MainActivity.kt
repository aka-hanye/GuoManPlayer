package com.akahan.guomanplayer

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

private val Ink = Color(0xFF292321)
private val Accent = Color(0xFFE85D4A)
private val Cream = Color(0xFFFFF9F6)
private val Soft = Color(0xFFF5EAE5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GuoManApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun GuoManApp() {
    val context = LocalContext.current
    var tab by remember { mutableStateOf(0) }
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var videoName by remember { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            videoUri = uri
            videoName = uri.lastPathSegment?.substringAfterLast('/') ?: "本地视频"
            tab = 1
        }
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Accent, background = Cream, surface = Color.White)) {
        Scaffold(
            containerColor = Cream,
            topBar = {
                TopAppBar(
                    title = { Column { Text("果漫播放器", fontWeight = FontWeight.Bold, color = Ink); Text("GuoManPlayer", fontSize = 11.sp, color = Color.Gray) } },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Cream)
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("首页") })
                    NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.PlayCircle, null) }, label = { Text("漫剧播放") })
                    NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.Bookmark, null) }, label = { Text("收藏") })
                    NavigationBarItem(selected = tab == 3, onClick = { tab = 3 }, icon = { Icon(Icons.Default.History, null) }, label = { Text("历史") })
                }
            }
        ) { padding ->
            when (tab) {
                0 -> HomeScreen(Modifier.padding(padding), onPick = { picker.launch(arrayOf("video/*")) }, onPlayer = { tab = 1 })
                1 -> PlayerScreen(Modifier.padding(padding), videoUri, videoName, onPick = { picker.launch(arrayOf("video/*")) })
                2 -> EmptyScreen(Modifier.padding(padding), "收藏夹", "播放并收藏喜欢的漫剧后，会在这里集中查看。", Icons.Default.Bookmark)
                else -> EmptyScreen(Modifier.padding(padding), "观看历史", "最近播放的本地视频会在这里显示。", Icons.Default.History)
            }
        }
    }
}

@Composable
private fun HomeScreen(modifier: Modifier, onPick: () -> Unit, onPlayer: () -> Unit) {
    LazyColumn(modifier.fillMaxSize().padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(16.dp), contentPadding = PaddingValues(top = 12.dp, bottom = 24.dp)) {
        item {
            Column(Modifier.fillMaxWidth().background(Soft, RoundedCornerShape(24.dp)).padding(22.dp)) {
                Text("把喜欢的故事，\n装进口袋里。", fontSize = 27.sp, lineHeight = 35.sp, fontWeight = FontWeight.Bold, color = Ink)
                Spacer(Modifier.height(8.dp))
                Text("红果入口 · AI 漫剧 · 本地视频播放", color = Color(0xFF786A64), fontSize = 13.sp)
                Spacer(Modifier.height(18.dp))
                Button(onClick = onPlayer, colors = ButtonDefaults.buttonColors(containerColor = Accent)) { Text("开始看漫剧") }
            }
        }
        item { Text("快捷入口", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Ink) }
        item {
            ActionCard(Icons.Default.VideoLibrary, "导入本地视频", "选择手机里的 MP4 等视频开始播放", onPick)
        }
        item {
            ActionCard(Icons.Default.AutoAwesome, "AI 漫剧播放器", "播放你保存到手机的 AI 漫剧视频", onPlayer)
        }
        item {
            Column(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(18.dp)).padding(16.dp)) {
                Text("红果短剧入口", fontWeight = FontWeight.Bold, color = Ink, fontSize = 16.sp)
                Spacer(Modifier.height(6.dp))
                Text("这里预留官方应用跳转入口。当前版本先提供独立播放器；不会伪装成红果官方应用。", color = Color.Gray, fontSize = 12.sp, lineHeight = 18.sp)
            }
        }
    }
}

@Composable
private fun ActionCard(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(18.dp)).clickable(onClick = onClick).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(48.dp).background(Soft, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = Accent) }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) { Text(title, color = Ink, fontWeight = FontWeight.SemiBold); Spacer(Modifier.height(3.dp)); Text(subtitle, color = Color.Gray, fontSize = 12.sp) }
        Icon(Icons.Default.ChevronRight, null, tint = Color.Gray)
    }
}

@Composable
private fun PlayerScreen(modifier: Modifier, uri: Uri?, name: String, onPick: () -> Unit) {
    val context = LocalContext.current
    var player by remember { mutableStateOf<ExoPlayer?>(null) }
    DisposableEffect(uri) {
        if (uri != null) {
            val p = ExoPlayer.Builder(context).build()
            p.setMediaItem(MediaItem.fromUri(uri)); p.prepare(); p.playWhenReady = true
            player = p
        }
        onDispose { player?.release(); player = null }
    }
    Column(modifier.fillMaxSize().padding(18.dp)) {
        Text("漫剧播放器", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Ink)
        Spacer(Modifier.height(12.dp))
        if (uri == null) {
            Box(Modifier.fillMaxWidth().weight(1f).background(Color(0xFF211E1D), RoundedCornerShape(20.dp)), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.PlayCircle, null, tint = Color.White, modifier = Modifier.size(64.dp))
                    Spacer(Modifier.height(12.dp)); Text("还没有选择视频", color = Color.White, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp)); Text("导入手机里的漫剧视频即可播放", color = Color.LightGray, fontSize = 12.sp)
                }
            }
        } else {
            Text(name, color = Ink, fontWeight = FontWeight.Medium, maxLines = 1)
            Spacer(Modifier.height(8.dp))
            AndroidView(
                modifier = Modifier.fillMaxWidth().weight(1f).background(Color.Black, RoundedCornerShape(16.dp)),
                factory = { ctx -> PlayerView(ctx).apply { this.player = player; useController = true } },
                update = { it.player = player }
            )
        }
        Spacer(Modifier.height(14.dp))
        Button(onClick = onPick, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Accent)) {
            Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(8.dp)); Text(if (uri == null) "选择视频" else "更换视频")
        }
    }
}

@Composable
private fun EmptyScreen(modifier: Modifier, title: String, message: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Column(modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(icon, null, tint = Accent, modifier = Modifier.size(52.dp))
        Spacer(Modifier.height(14.dp)); Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Ink)
        Spacer(Modifier.height(8.dp)); Text(message, color = Color.Gray, fontSize = 13.sp)
    }
}
